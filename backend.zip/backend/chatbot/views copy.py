from django.shortcuts import render
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from data.models import Data
from django.http import JsonResponse
import openai
import pandas as pd
import json
import os
class ChatbotAPIView(APIView):
    def get(self, request, format=None):
        query = request.GET.get('query')
        insights_data = ai_function(query)
        #print("GGGGGGGGGG",insights_data)
        return Response({"insights": insights_data})

    
    
import json

def ai_function(query):    
    data = Data.objects.all()
    df = queryset_to_dataframe(data)
    #print("XXXXXXXXXXXXXXXXXX", df.columns)
    
    # Step 3: Preprocess Data (if needed)
    # Perform any necessary preprocessing steps on the DataFrame
    
    # Step 4: Define Input Prompt
    prompt = construct_prompt(df, query)
    
    # Step 5: Use GPT for Analysis
    insights = analyze_with_gpt(prompt)
    
    # Check if insights is a dictionary
    if isinstance(insights, dict):
        insights_data = insights.get('insights')  # Access insights using .get() method
    else:
        # Handle the case where insights is not a dictionary
        insights_data = "No insights available"
    
    # Step 6: Output Analysis Results
    return insights






def queryset_to_dataframe(queryset):
    # Convert Django queryset to pandas DataFrame
    # Assuming your queryset has attributes named 'field1', 'field2', etc.
    data = list(queryset.values())
    df = pd.DataFrame(data)
    return df
def analyze_with_gpt(prompt):
    # Set your OpenAI API key
    openai.api_key = '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'
    
    # Generate text using GPT
    response = openai.Completion.create(
        engine="gpt-3.5-turbo-instruct",  # Choose the appropriate GPT model
        prompt=prompt,
        max_tokens=100  # Adjust the max_tokens parameter to a lower value
    )
    
    # Get the generated text
    result = response.choices[0].text.strip()
    return result



def construct_prompt(df, query):
    # Get the value counts for the 'secnew' column
    secnew_counts = df['secnew'].value_counts()
    
    # Use df_map function to map secnew values
    mapped_counts = df_map(df,  'secnew')
    
    # Convert the value counts to a string
    secnew_counts_str = mapped_counts.value_counts().to_string()

    print(secnew_counts_str)
    
    # Construct the prompt with the value counts and user query
    prompt = f"{query}:\n\n{mapped_counts.value_counts()}"
    #prompt += f"User Query:\n{query}\n"
    
    return prompt


def df_map(df, side):
    if convert_keys_to_int(side)==False:
        side_mapped=df[side]

    else:
        mp=convert_keys_to_int(side)
        dmp = {int(key): value for key, value in mp.items()}
        #dmp={1: 'SEC A', 2: 'SEC B', 3: 'SEC C1', 4: 'SEC C2', 5: 'SEC D', 6: 'SEC E'}
        side_mapped = df[side].map(dmp)

    return side_mapped

def convert_keys_to_int(field):
    # Construct the file path
    file_path = os.path.join(os.getcwd(), "crosstab", "datamap.json")
    #print(file_path)
    # Initialize the formatted key dictionary
    formatted_key = {}
    
    # Read the input data from the JSON file
    with open(file_path, "r") as file:
        input_data = json.load(file)
    
    # Check if the field matches any key in the input data
    if field in input_data:
        print("a1")
        # Retrieve the dictionary corresponding to the field
        dmap = input_data[field]
        
        # Iterate over the key-value pairs in the dictionary
        for k, v in dmap.items():
            # Check if v is a dictionary
            if isinstance(v, dict):
                # If v is a dictionary, assign it directly
                formatted_key[k] = v
            else:
                # If v is not a dictionary, assign it directly
                formatted_key[k] = v
        
        return formatted_key
    else:
        return False


from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from data.models import Data
from django.http import JsonResponse
import pandas as pd
import json
import os

class ChatbotAPIView(APIView):
    def get(self, request, format=None):
        query = request.GET.get('query')
        insights_data = ai_function(query)
        insights_str = '\n'.join([' '.join(map(str, item)) for item in insights_data])
        return JsonResponse({"insights": insights_str})

def ai_function(query):
    """
    Custom function to handle queries and generate insights.
    """
    # Retrieve data from Django models
    data = YourModel.objects.all()  # Replace YourModel with your actual Django model

    # Convert the queryset to a DataFrame
    df = queryset_to_dataframe(data)

    # Parse the query to get columns and filters
    columns, filters = parse_query(query, df)

    # Apply filters to the DataFrame
    filtered_df = df.copy()
    for field, value in filters.items():
        filtered_df = filtered_df[filtered_df[field] == value]

    # Generate insights based on the query type
    if "distribution" in query:
        insights_data = get_distribution(filtered_df, columns[0])
    elif "summary" in query:
        insights_data = get_summary(filtered_df, columns[0])
    elif "in %" in query:
        insights_data = get_percentage_distribution(filtered_df, columns[0])
    else:
        insights_data = []

    return insights_data

def queryset_to_dataframe(queryset):
    data = list(queryset.values())
    df = pd.DataFrame(data)
    return df

def parse_query(query, df):
    columns = []
    filters = {}
    
    # Check if the query contains the keyword 'column'
    if 'column' in query:
        # Split the query string by 'column'
        parts = query.split('column')
        
        # Extract the column name from the second part (after 'column')
        column_part = parts[1].strip()
        columns.append(column_part)
        
        # Check if there are any additional filters specified after the column
        if len(parts) > 1:
            filter_parts = parts[1].split()  # Split by whitespace to handle filters after the column
            if len(filter_parts) > 1:
                filter_name = filter_parts[0].strip()
                filter_value = " ".join(filter_parts[1:]).strip()  # Join remaining parts as filter value
                filters[filter_name] = filter_value
    
    return columns, filters

def get_distribution(df, column):
    column_counts = df[column].value_counts()
    insights_data = [(index, value) for index, value in column_counts.items()]
    return insights_data

def get_summary(df, column):
    column_summary = df[column].describe().to_dict()
    insights_data = [(key, column_summary[key]) for key in column_summary]
    return insights_data

def get_percentage_distribution(df, column):
    total_count = df[column].count()
    column_counts = df[column].value_counts(normalize=True) * 100
    insights_data = [(index, value) for index, value in column_counts.items()]
    return insights_data

def df_map(df):
    # Load datamap from JSON file
    datamap_path =  os.path.join(os.getcwd(), "crosstab", "datamap.json")
    with open(datamap_path, "r") as file:
        datamap = json.load(file)
    
    # Iterate over columns in the DataFrame
    for column in df.columns:
        # Check if the column has a mapping in the datamap
        if column in datamap:
            mapping = datamap[column]
            int_mapping = {int(key): value for key, value in mapping.items()}
            # Apply mapping to column values
            df[column] = df[column].map(int_mapping)
 
    return df
